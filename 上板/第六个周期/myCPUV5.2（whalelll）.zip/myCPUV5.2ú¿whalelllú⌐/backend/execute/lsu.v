// ============================================================
// lsu 模块（访存单元：AGU + DC 两级流水 + miss 槽非阻塞 load）
// ------------------------------------------------------------
// 结构：
// - issue→AGU 边界先计算并锁存 vaddr=base+imm；AGU 级只做 MMU 组合翻译、
//   ALE/ADEM/TLB 异常与 store 对齐，避免地址加法和 TLB 搜索串在同一拍 ->
//   store 数据按地址对齐 + wstrb 生成；
// - DC 级：store/cacop/异常直接写回；load 先查 SB 前递，再访 DCache；
// - miss 槽（深度 `LSU_MISS_DEPTH`）：cached miss 移入槽，robid 配对返回；
// - 写回仲裁：miss 槽 > hold > DC 级；SB/DC 命中经 hold 打拍。
//
// 顺序保护（P1b：STQ + 提交后 SB）：
// - store 写回后入 STQ（深度 `STQ_DEPTH`），提交前挡重叠 / UC 全局互斥；
// - 已提交 store 经 commit 推 SB；字节 overlap 与 SB 共用 mycpu.h 中 mem_* 函数。
//
// 冲刷（flush_i）：
// - 清 AGU/DC/hold/STQ/UC-park（SB 不清：已提交）；
// - d_drop 丢弃在途前端响应；miss 槽置 m_drop 等 mshr_data_ok。
//
// 年轻 UC park：比 UC 更老的 AGU 可让出 DC（宽版，见流水推进注释）。
// ============================================================
`include "mycpu.h"

module lsu(
    input  wire                       clk,
    input  wire                       reset,
    input  wire                       flush_i,

    // ---------------- 发射入口（来自 rs_mem）----------------
    input  wire                       issue_valid_i,
    input  wire [`ROB_W-1:0]          issue_robid_i,
    input  wire [`MEM_OP_NUM-1:0]     issue_mem_op_i,
    input  wire                       issue_is_cacop_i,
    input  wire [4:3]                 issue_cacop_op_i,
    input  wire [31:0]                issue_base_i,        // rj 值
    input  wire [31:0]                issue_wdata_i,       // rd 值（store 数据）
    input  wire [31:0]                issue_imm_i,         // 偏移
    output wire                       lsu_ready_o,         // AGU 级可接收

    // ---------------- D 侧地址翻译（连 mmu D 通道，组合）----------------
    output wire                       mmu_d_req_o,
    output wire [31:0]                mmu_d_vaddr_o,
    output wire                       mmu_d_is_store_o,    // 区分 PIL/PIS 与 PME
    input  wire [31:0]                mmu_d_paddr_i,
    input  wire [1:0]                 mmu_d_mat_i,
    input  wire                       mmu_d_ready_i,
    input  wire                       mmu_d_excp_tlbr_i,
    input  wire                       mmu_d_excp_pil_i,
    input  wire                       mmu_d_excp_pis_i,
    input  wire                       mmu_d_excp_ppi_i,
    input  wire                       mmu_d_excp_pme_i,
    input  wire                       mmu_d_excp_adem_i,

    // ---------------- DCache load 访问口 ----------------
    output wire                       dc_req_o,            // load 请求（保持至 addr_ok）
    output wire [11:5]                dc_vindex_o,         // 虚地址页内索引（VIPT）
    output wire [31:0]                dc_paddr_o,          // 物理地址（tag 比对）
    output wire [2:0]                 dc_size_o,           // 0=B 1=H 2=W
    output wire                       dc_uncached_o,
    output wire [`ROB_W-1:0]          dc_robid_o,          // 随 dc_req：D$ miss 锁存配对
    input  wire                       dc_addr_ok_i,
    input  wire                       dc_data_ok_i,
    input  wire [31:0]                dc_rdata_i,
    input  wire [`ROB_W-1:0]          dc_resp_robid_i,
    output wire                       dc_resp_ready_o,
    output wire                       dc_cancel_o,         // 冲刷：通知 dcache 杀 load MSHR
    // ---- 非阻塞 miss 扩展（配合 dcache MSHR）----
    input  wire                       dc_miss_i,           // 在途 load 移入 MSHR（一拍）
    input  wire                       dc_mshr_data_ok_i,   // MSHR 重填数据返回（一拍）
    input  wire [31:0]                dc_mshr_rdata_i,
    input  wire [`ROB_W-1:0]          dc_mshr_robid_i,     // 与 data_ok 同拍

    // ---------------- store buffer 前递查询（DC 级，一拍返回）----------------
    output wire                       sb_query_valid_o,
    output wire [31:2]                sb_query_paddr_o,
    output wire                       sb_query_uncached_o, // 本查询来自 uncached load
    input  wire                       sb_query_resp_valid_i,
    input  wire [31:2]                sb_query_resp_paddr_i,
    input  wire                       sb_query_resp_uncached_i,
    input  wire                       sb_query_maybe_i,
    input  wire                       sb_query_hit_i,      // 整字可由 SB 合并前递
    input  wire [31:0]                sb_query_data_i,
    input  wire                       sb_query_partial_i,  // 部分命中：load 等排空重试
    input  wire                       sb_empty_i,

    // ---------------- uncached load 许可（与 ROB head 比较）----------------
    input  wire [`ROB_W-1:0]          rob_head_robid_i,    // 编码：MSB=槽0 仍未提交，低位=head 对指针（顶层拼装，见 mycpu_top）
    input  wire                       rob_head_valid_i,
    // store 提交释放 STQ：与 SB push 同源；LSU 再打一拍，保证 SB valid 已可见
    input  wire                       st_retire_valid_i,
    input  wire [`ROB_W-1:0]          st_retire_robid_i,
    output wire                       uncached_ld_inflight_o, // 有 uncached load 在飞（commit 屏蔽中断用）

    // ---------------- 写回 ROB ----------------
    output wire                       wb_valid_o,
    output wire [`ROB_W-1:0]          wb_robid_o,
    output wire [31:0]                wb_data_o,           // load 整形后数据 / store 写数据
    output wire [31:0]                wb_paddr_o,          // 访存物理地址（store/cacop/difftest 用）
    output wire [31:0]                wb_vaddr_o,          // 访存虚地址（BADV/difftest 用）
    output wire [3:0]                 wb_wstrb_o,          // store 字节使能（已按地址对齐移位）
    output wire [2:0]                 wb_size_o,           // 访问宽度
    output wire                       wb_uncached_o,       // 非缓存访问
    output wire [`EXCP_NUM-1:0]       wb_excp_o,           // 动态异常（ALE/ADEM/TLBR_M/PIL/PIS/PPI_M/PME）

    // Dedicated same-cycle cached load-hit bypass.  Miss/hold/store
    // completions remain exclusively on the normal writeback path.
    output wire                       fast_wb_valid_o,
    output wire [`ROB_W-1:0]          fast_wb_robid_o,
    output wire [31:0]                fast_wb_data_o,
    // Registered hold-only subset for timing-sensitive consumers such as MDU.
    output wire                       hold_wb_valid_o,
    output wire [`ROB_W-1:0]          hold_wb_robid_o,
    output wire [31:0]                hold_wb_data_o,

    // ---------------- DC 级命中限定早唤醒（顶层可选择打一拍）----------------
    output wire                       early_wakeup_valid_o,
    output wire [`ROB_W-1:0]          early_wakeup_robid_o
);

// =====================================================================
// AGU 级
// =====================================================================
reg                    a_valid;
reg [`ROB_W-1:0]       a_robid;
reg [`MEM_OP_NUM-1:0]  a_mem_op;
reg                    a_is_cacop;
reg [4:3]              a_cacop_op;
reg [31:0]             a_vaddr, a_wdata;

// One-entry issue skid. LSU ready depends only on this register, so the
// store-buffer forwarding cone cannot reach back into rs_mem.
reg                    q_valid;
reg [`ROB_W-1:0]       q_robid;
reg [`MEM_OP_NUM-1:0]  q_mem_op;
reg                    q_is_cacop;
reg [4:3]              q_cacop_op;
reg [31:0]             q_vaddr, q_wdata;

wire a_is_store_op = a_mem_op[`MEM_OP_ST_W] | a_mem_op[`MEM_OP_ST_B]
                   | a_mem_op[`MEM_OP_ST_H] | a_mem_op[`MEM_OP_SC_W];
wire a_is_load_op  = a_mem_op[`MEM_OP_LD_W] | a_mem_op[`MEM_OP_LD_B]
                   | a_mem_op[`MEM_OP_LD_H] | a_mem_op[`MEM_OP_LD_BU]
                   | a_mem_op[`MEM_OP_LD_HU]| a_mem_op[`MEM_OP_LL_W];

// MMU 翻译（组合）：ALE / Index-cacop 抑制翻译请求
// ALE 检测（H 类要求 vaddr[0]==0，W/LL/SC 要求 vaddr[1:0]==00）
// VA 对齐先于地址翻译：ALE 时不得发 MMU，否则会与 TLBR 同拍置位，
// 否则 ALE 会与 TLBR 同拍置位，破坏异常优先级。
// 注意：cacop 的 Index 类用 rj+si12 编码 way/index，低位可非对齐，不能一律按字对齐报 ALE。
wire a_size_h = a_mem_op[`MEM_OP_LD_H] | a_mem_op[`MEM_OP_LD_HU] | a_mem_op[`MEM_OP_ST_H];
wire a_size_w = a_mem_op[`MEM_OP_LD_W] | a_mem_op[`MEM_OP_ST_W]
              | a_mem_op[`MEM_OP_LL_W] | a_mem_op[`MEM_OP_SC_W];
wire a_ale = (a_size_h && (a_vaddr[0] != 1'b0))
           | (a_size_w && (a_vaddr[1:0] != 2'b00));

// Index/StoreTag（op[4:3]=00/01）使用虚地址编码 way/index，不走地址翻译。
// 否则 Index cacop 会在 PG 下误报 TLBR，difftest 见 CRMD DA↔PG / TLBR vs ALE。
wire a_cacop_di = a_is_cacop && ((a_cacop_op == 2'b00) || (a_cacop_op == 2'b01));
wire a_no_trans = a_ale | a_cacop_di;

assign mmu_d_req_o      = a_valid && !a_no_trans;
assign mmu_d_vaddr_o    = a_vaddr;
assign mmu_d_is_store_o = a_is_store_op;

// LoongArch MAT：2'b01=coherent cached，其余按 uncached 访问
wire a_uncached = (mmu_d_mat_i != 2'b01);
// Index cacop：paddr=vaddr（作 way/index），无 MAT 语义
wire [31:0] a_paddr = a_cacop_di ? a_vaddr : mmu_d_paddr_i;

// 异常合并；ALE / Index-cacop 屏蔽翻译类异常
wire [`EXCP_NUM-1:0] a_excp =
      ({{(`EXCP_NUM-1){1'b0}}, a_ale}                                    << `EXCP_ALE)
    | ({{(`EXCP_NUM-1){1'b0}}, !a_no_trans & mmu_d_excp_adem_i}          << `EXCP_ADEM)
    | ({{(`EXCP_NUM-1){1'b0}}, !a_no_trans & mmu_d_excp_tlbr_i} << `EXCP_TLBR_M)
    | ({{(`EXCP_NUM-1){1'b0}}, !a_no_trans & mmu_d_excp_pil_i}  << `EXCP_PIL)
    | ({{(`EXCP_NUM-1){1'b0}}, !a_no_trans & mmu_d_excp_pis_i}  << `EXCP_PIS)
    | ({{(`EXCP_NUM-1){1'b0}}, !a_no_trans & mmu_d_excp_ppi_i}  << `EXCP_PPI_M)
    | ({{(`EXCP_NUM-1){1'b0}}, !a_no_trans & mmu_d_excp_pme_i}  << `EXCP_PME);

// store 数据按地址对齐 + wstrb
wire [1:0] a_off = a_vaddr[1:0];
reg [31:0] a_st_data;
reg [3:0]  a_st_strb;
always @(*) begin
    if (a_mem_op[`MEM_OP_ST_B]) begin
        a_st_data = {4{a_wdata[7:0]}};
        a_st_strb = 4'b0001 << a_off;
    end else if (a_mem_op[`MEM_OP_ST_H]) begin
        a_st_data = {2{a_wdata[15:0]}};
        a_st_strb = a_off[1] ? 4'b1100 : 4'b0011;
    end else begin
        a_st_data = a_wdata;
        a_st_strb = 4'b1111;
    end
end

wire [2:0] a_size = a_mem_op[`MEM_OP_ST_B] | a_mem_op[`MEM_OP_LD_B] | a_mem_op[`MEM_OP_LD_BU] ? 3'd0
                  : a_mem_op[`MEM_OP_ST_H] | a_mem_op[`MEM_OP_LD_H] | a_mem_op[`MEM_OP_LD_HU] ? 3'd1
                  : 3'd2;

// =====================================================================
// DC 级
// =====================================================================
reg                    d_valid;
reg [`ROB_W-1:0]       d_robid;
reg [`MEM_OP_NUM-1:0]  d_mem_op;
reg                    d_is_cacop;
reg                    d_is_store, d_is_load;
reg [31:0]             d_vaddr, d_paddr;
reg [31:0]             d_st_data;
reg [3:0]              d_st_strb;
reg [2:0]              d_size;
reg                    d_uncached;
reg [`EXCP_NUM-1:0]    d_excp;

// ---------------- DCache 前端请求标签（最多 4 项）----------------
// DCache 可以把一个冲突请求挂入 pending，同时继续完成后续 hit，因此命中响应
// 不能再隐含绑定当前 d 级。每次 addr_ok 时保存完整 load 元数据，命中/miss
// 返回时由 DCache 给出的 robid 精确匹配。flush 同时清表；DCache 内部取消旧
// MSHR/LOOKUP 响应，避免 ROB 标签复用后的 ABA。
localparam TOK_N = 4;
localparam TOK_W = 2;

function automatic [TOK_W-1:0] lsu_tok_prio_low;
    input [TOK_N-1:0] mask;
    integer k;
    reg found;
    begin
        lsu_tok_prio_low = {TOK_W{1'b0}};
        found = 1'b0;
        for (k = 0; k < TOK_N; k = k + 1) begin
            if (mask[k] && !found) begin
                lsu_tok_prio_low = k[TOK_W-1:0];
                found = 1'b1;
            end
        end
    end
endfunction

reg                    t_valid    [0:TOK_N-1];
reg [`ROB_W-1:0]       t_robid    [0:TOK_N-1];
reg [`MEM_OP_NUM-1:0]  t_mem_op   [0:TOK_N-1];
reg [31:0]             t_vaddr    [0:TOK_N-1];
reg [31:0]             t_paddr    [0:TOK_N-1];
reg [2:0]              t_size     [0:TOK_N-1];
reg                    t_uncached [0:TOK_N-1];
// Timing-only validity mirror indexed directly by ROB id. DCache already
// returns the request ROB id, so raw dependency wakeup need not traverse the
// four-entry token CAM and priority encoder.
reg [`ROB_SIZE-1:0]    fast_tok_valid;

wire [TOK_N-1:0] t_valid_oh;
wire [TOK_N-1:0] t_free_oh;
wire [TOK_N-1:0] t_match_oh;
genvar ti;
generate
for (ti = 0; ti < TOK_N; ti = ti + 1) begin : g_tok_status
    assign t_valid_oh[ti] = t_valid[ti];
    assign t_free_oh[ti]  = !t_valid[ti];
    assign t_match_oh[ti] = t_valid[ti] && (t_robid[ti] == dc_resp_robid_i);
end
endgenerate
wire             t_has_free  = |t_free_oh;
wire [TOK_W-1:0] t_free_idx  = lsu_tok_prio_low(t_free_oh);
wire             t_match_vld = |t_match_oh;
wire [TOK_W-1:0] t_match_idx = lsu_tok_prio_low(t_match_oh);

// 保留原调试层次名，但语义改为“至少一个 DCache 前端 token 在途”。
wire d_req_sent = |t_valid_oh;
wire d_drop = 1'b0;

// ---------------- miss 槽（MSHR 影子，深度 LSU_MISS_DEPTH）----------------
localparam MISS_N = `LSU_MISS_DEPTH;
localparam MISS_W = (MISS_N <= 1) ? 1 : $clog2(MISS_N);

function automatic [MISS_W-1:0] lsu_miss_prio_low;
    input [MISS_N-1:0] mask;
    integer k;
    reg found;
    begin
        lsu_miss_prio_low = {MISS_W{1'b0}};
        found = 1'b0;
        for (k = 0; k < MISS_N; k = k + 1) begin
            if (mask[k] && !found) begin
                lsu_miss_prio_low = k[MISS_W-1:0];
                found = 1'b1;
            end
        end
    end
endfunction

reg                    m_valid [0:MISS_N-1];
reg                    m_drop  [0:MISS_N-1];
reg [`ROB_W-1:0]       m_robid [0:MISS_N-1];
reg [`MEM_OP_NUM-1:0]  m_mem_op[0:MISS_N-1];
reg [31:0]             m_vaddr [0:MISS_N-1];
reg [31:0]             m_paddr [0:MISS_N-1];
reg [2:0]              m_size  [0:MISS_N-1];

wire [MISS_N-1:0] m_valid_oh;
wire [MISS_N-1:0] m_free_oh;
wire [MISS_N-1:0] m_drop_oh;
wire [MISS_N-1:0] m_match_oh;
genvar mi;
generate
for (mi = 0; mi < MISS_N; mi = mi + 1) begin : g_miss_status
    assign m_valid_oh[mi] = m_valid[mi];
    assign m_free_oh[mi]  = !m_valid[mi];
    assign m_drop_oh[mi]  = m_valid[mi] && m_drop[mi];
    assign m_match_oh[mi] = m_valid[mi] && dc_mshr_data_ok_i
                         && (m_robid[mi] == dc_mshr_robid_i);
end
endgenerate
wire              m_has_free   = |m_free_oh;
wire [MISS_W-1:0] m_free_idx   = lsu_miss_prio_low(m_free_oh);
// 同 robid 时优先吃 drop 槽，避免冲刷后复用 robid 的新 load 吃到旧 MSHR 数据
wire [MISS_N-1:0] m_match_drop = m_match_oh & m_drop_oh;
wire [MISS_N-1:0] m_match_live = m_match_oh & ~m_drop_oh;
wire              m_match_vld  = |m_match_oh;
wire [MISS_W-1:0] m_match_idx  = (|m_match_drop)
                               ? lsu_miss_prio_low(m_match_drop)
                               : lsu_miss_prio_low(m_match_live);

// ---------------- 写回暂存槽（被高优先级抢口的瞬态完成）----------------
reg                    h_valid;
reg [`ROB_W-1:0]       h_robid;
reg [31:0]             h_data;          // 已整形
reg [31:0]             h_vaddr, h_paddr;
reg [2:0]              h_size;

// 年轻 UC load 旁路槽：未到 ROB 头时让出 DC，避免堵住年老访存
reg                    u_valid;
reg [`ROB_W-1:0]       u_robid;
reg [`MEM_OP_NUM-1:0]  u_mem_op;
reg [31:0]             u_vaddr, u_paddr;
reg [2:0]              u_size;

// ---------------- 顺序保护：未决 store 地址队列（WBed 尚未提交）----------------
localparam STQ_N = `STQ_DEPTH;
localparam STQ_W = (STQ_N <= 1) ? 1 : $clog2(STQ_N);

reg                  stq_v    [0:STQ_N-1];
reg [`ROB_W-1:0]     stq_id   [0:STQ_N-1];
reg [31:0]           stq_pa   [0:STQ_N-1];
reg [31:0]           stq_data [0:STQ_N-1];
reg [3:0]            stq_strb [0:STQ_N-1];
reg                  stq_uc   [0:STQ_N-1];
// Index of the most recently issued store.  Memory stores issue in program
// order, so this is the only entry that can supersede every older overlapping
// store without a 16-entry youngest-age priority network.
reg [STQ_W-1:0]      stq_last_idx;

wire [`ROB_PAIR_W-1:0] head_pair   = rob_head_robid_i[`ROB_PAIR_W-1:0];
wire                   head_s0_live= rob_head_robid_i[`ROB_W-1];

// STQ 释放：仅在 store 真正提交进 SB 的下一拍清项（避免 age-wrap 误释放，
// 以及提交当拍 SB valid 尚未打拍导致的错载窗口）。
reg                    st_ret_v_r;
reg [`ROB_W-1:0]       st_ret_id_r;
always @(posedge clk) begin
    if (reset || flush_i) begin
        st_ret_v_r  <= 1'b0;
        st_ret_id_r <= {`ROB_W{1'b0}};
    end else begin
        st_ret_v_r  <= st_retire_valid_i;
        st_ret_id_r <= st_retire_robid_i;
    end
end

wire                   stq_done [0:STQ_N-1];
genvar si;
generate
for (si = 0; si < STQ_N; si = si + 1) begin : g_stq_cm
    assign stq_done[si] = stq_v[si] && st_ret_v_r && (stq_id[si] == st_ret_id_r);
end
endgenerate

// load 访问字节掩码（实现见 mycpu.h）
wire [3:0] d_ld_bytes = mem_load_byte_mask(d_mem_op[7:4], d_vaddr[1:0]);

wire stq_any;
wire stq_any_uc;
wire stq_overlap;
wire [STQ_N-1:0] stq_hit_one;
generate
for (si = 0; si < STQ_N; si = si + 1) begin : g_stq_hz
    // Keep an entry visible through its retirement cycle.  It is safe to wait
    // or forward from that store for one extra cycle, and this deliberately
    // removes ROB commit logic from the LSU request critical path.
    assign stq_hit_one[si] = stq_v[si]
        && mem_st_ld_overlap(stq_pa[si][31:2], stq_strb[si], d_paddr[31:2], d_ld_bytes);
end
endgenerate

integer sj;
reg stq_any_r, stq_any_uc_r;
always @(*) begin
    stq_any_r = 1'b0;
    stq_any_uc_r = 1'b0;
    for (sj = 0; sj < STQ_N; sj = sj + 1) begin
        if (stq_v[sj]) begin
            stq_any_r = 1'b1;
            if (stq_uc[sj])
                stq_any_uc_r = 1'b1;
        end
    end
end
assign stq_any     = stq_any_r;
assign stq_any_uc  = stq_any_uc_r;
assign stq_overlap = |stq_hit_one;

// Timing-safe store-to-load forwarding.  Only the globally newest live store
// is considered.  When it covers every requested byte it necessarily
// supersedes all older stores.  Other overlaps retain the conservative wait
// path.  This trades a few forwarding opportunities for a single indexed
// read, replacing the former 16-entry serial age/priority cone.
wire        stq_last_valid = stq_v[stq_last_idx];
wire [31:0] stq_youngest_data_r = stq_data[stq_last_idx];
wire [3:0]  stq_youngest_strb_r = stq_strb[stq_last_idx];
wire stq_fwd_hit = stq_last_valid && !stq_uc[stq_last_idx]
                 && (stq_pa[stq_last_idx][31:2] == d_paddr[31:2])
                 && ((stq_youngest_strb_r & d_ld_bytes) == d_ld_bytes);

wire stq_full;
reg stq_full_r;
always @(*) begin
    stq_full_r = 1'b1;
    for (sj = 0; sj < STQ_N; sj = sj + 1)
        if (!stq_v[sj])
            stq_full_r = 1'b0;
end
assign stq_full = stq_full_r;

wire store_order_block = d_uncached ? stq_any
                                    : ((stq_overlap && !stq_fwd_hit) || stq_any_uc);

// ---------------- DC 级行为 ----------------
wire d_excp_any = |d_excp;

// SB 前递查询。空 SB 是短旁路；非空时由 SB 内部寄存完整扫描结果，
// 返回 tag 必须与保持中的 D 级物理字地址及缓存属性一致。
assign sb_query_paddr_o    = d_paddr[31:2];
assign sb_query_uncached_o = d_valid && d_is_load && d_uncached;
wire sb_query_needed = d_valid && d_is_load && !d_excp_any
                     && (d_uncached || !stq_fwd_hit)
                     && !sb_empty_i && sb_query_maybe_i;
assign sb_query_valid_o = sb_query_needed;
wire sb_query_resp_match = sb_query_resp_valid_i
                         && (sb_query_resp_paddr_i == d_paddr[31:2])
                         && (sb_query_resp_uncached_i == d_uncached);
wire sb_query_ready = !sb_query_needed || sb_query_resp_match;

// uncached load 许可：自己是最老未提交指令
wire d_at_head = (d_robid[`ROB_PAIR_W-1:0] == head_pair)
              && ((d_robid[`ROB_W-1] == 1'b0) || !head_s0_live)
              && rob_head_valid_i;

wire d_is_unc_load = d_valid && d_is_load && d_uncached && !d_excp_any;
assign uncached_ld_inflight_o = d_is_unc_load || u_valid;

// load 可以发起最终访问（SB 终查/DCache）的条件：
// - 未决 store 先提交（顺序保护）；
// - hold 槽空（防瞬态完成三方碰撞，见头注仲裁说明）；
// - uncached load 额外等：到 ROB 头 + SB 无 uncached 残留（query_partial）
wire d_ld_gate = !store_order_block && !h_valid && t_has_free
              && sb_query_ready
              && (!d_uncached
                  || (d_at_head
                      && !(sb_query_resp_match && sb_query_partial_i)));

// load 处理分支
wire d_stq_hit    = d_valid && d_is_load && !d_excp_any && !d_uncached && stq_fwd_hit;
wire d_sb_hit     = d_valid && d_is_load && !d_excp_any && !d_uncached
                  && !d_stq_hit && sb_query_needed
                  && sb_query_resp_match && sb_query_hit_i;
wire d_sb_partial = d_valid && d_is_load && !d_excp_any && !d_uncached
                  && sb_query_needed && sb_query_resp_match
                  && sb_query_partial_i;

wire d_need_dc = d_valid && d_is_load && !d_excp_any
              && !d_stq_hit && !d_sb_hit && !d_sb_partial;

// DCache 请求（保持至 addr_ok）。addr_ok 后 d 级立即释放；返回元数据由 token
// 表承担，因此连续 hit 可以利用 DCache LOOKUP 链做到每拍一条。
assign dc_req_o      = d_need_dc && d_ld_gate && !flush_i;
assign dc_vindex_o   = d_vaddr[11:5];
assign dc_paddr_o    = d_paddr;
assign dc_size_o     = d_size;
assign dc_uncached_o = d_uncached;
assign dc_robid_o    = d_robid;
assign dc_cancel_o   = flush_i;

wire dc_fire = dc_req_o && dc_addr_ok_i;
// data_ok 是 valid，ready 由 LSU 的单项完成暂存槽反压；miss 通知不需占
// 写回口，只把 token 元数据移入已有 MSHR 影子槽。
wire dc_return_valid = dc_data_ok_i && t_match_vld;
wire dc_return       = dc_return_valid && dc_resp_ready_o;
wire dc_missed       = dc_miss_i && t_match_vld;

// MSHR 重填返回（按 robid 配对；m_drop 时静默消费）
wire mshr_return      = m_match_vld && !m_drop[m_match_idx];
wire mshr_return_drop = m_match_vld &&  m_drop[m_match_idx];

// ---------------- load 数据整形 ----------------
function [31:0] shape_load;
    input [31:0] word;
    input [7:4] op;
    input [1:0] off;
    reg [7:0]  b;
    reg [15:0] h;
    begin
        b = word[8*off +: 8];
        h = off[1] ? word[31:16] : word[15:0];
        if (op[`MEM_OP_LD_B])       shape_load = {{24{b[7]}}, b};
        else if (op[`MEM_OP_LD_BU]) shape_load = {24'b0, b};
        else if (op[`MEM_OP_LD_H])  shape_load = {{16{h[15]}}, h};
        else if (op[`MEM_OP_LD_HU]) shape_load = {16'b0, h};
        else                        shape_load = word;
    end
endfunction

// ---------------- 写回仲裁（一拍一条，按年龄：miss 槽 > hold > DC 级）----------------
// DC 级完成源：
// 1) 异常：直接写回；2) store/cacop：直接写回；3) load：SB 命中或 DCache 返回
wire wb_mshr_case  = mshr_return;                       // 最老，最高优先
wire wb_hold_case  = !wb_mshr_case && h_valid;
// 旧 hold 被写回的拍可由新 hit 原位补入；MSHR 抢口且 hold 已占用时反压
// DCache，让 LOOKUP 保持到下一拍，所有 accepted load 都不会丢响应。
assign dc_resp_ready_o = !h_valid || wb_hold_case;
wire wb_ld_dc_case = !wb_mshr_case && !h_valid && dc_return;
wire dcst_ok       = !wb_mshr_case && !h_valid && !dc_return;
wire wb_excp_case  = dcst_ok && d_valid && d_excp_any;
wire wb_st_case    = dcst_ok && d_valid && !d_excp_any && (d_is_store || d_is_cacop)
                  && !(d_is_store && stq_full);
// SB 命中结果经 hold 暂存一拍，隔离逐字节前递合并到写回旁路的长组合路径。
// flush 会丢弃尚未提交的 hold 内容；store_order_block 保证 store→load 顺序。
wire stq_ready     = d_stq_hit && d_ld_gate && !store_order_block;
wire sb_ready      = d_sb_hit && d_ld_gate && !store_order_block; // d_ld_gate 已含 !h_valid
wire wb_ld_sb_case = 1'b0;                               // SB 命中仍走 hold，切断 SB→RS 组合路径
// D$ 返回由 robid token 解包；被 MSHR/旧 hold 抢口时进入 hold。
wire hold_cap_dc   = dc_return && !wb_ld_dc_case;
// 所有就绪 SB 命中都进 hold(与 hold_cap_dc 互斥:同一 d 级 load 不会既 SB 命中又 DC 返回)
wire hold_cap_stq  = stq_ready && !hold_cap_dc;
wire hold_cap_sb   = sb_ready && !hold_cap_dc && !hold_cap_stq;

assign wb_valid_o = (wb_mshr_case || wb_hold_case
                  || wb_excp_case || wb_st_case || wb_ld_sb_case || wb_ld_dc_case)
                  && !flush_i;
assign wb_robid_o = wb_mshr_case ? m_robid[m_match_idx]
                  : wb_hold_case ? h_robid
                  : wb_ld_dc_case ? t_robid[t_match_idx]
                  : d_robid;
assign wb_data_o  = wb_mshr_case  ? shape_load(dc_mshr_rdata_i, m_mem_op[m_match_idx][7:4], m_vaddr[m_match_idx][1:0])
                  : wb_hold_case  ? h_data
                  : wb_ld_sb_case ? shape_load(sb_query_data_i, d_mem_op[7:4], d_vaddr[1:0])
                  : wb_ld_dc_case ? shape_load(dc_rdata_i, t_mem_op[t_match_idx][7:4],
                                               t_vaddr[t_match_idx][1:0])
                  : d_st_data;
assign wb_paddr_o = wb_mshr_case ? m_paddr[m_match_idx]
                  : wb_hold_case ? h_paddr
                  : wb_ld_dc_case ? t_paddr[t_match_idx] : d_paddr;
assign wb_vaddr_o = wb_mshr_case ? m_vaddr[m_match_idx]
                  : wb_hold_case ? h_vaddr
                  : wb_ld_dc_case ? t_vaddr[t_match_idx] : d_vaddr;
assign wb_wstrb_o = (!wb_mshr_case && !wb_hold_case && !wb_ld_dc_case
                  && d_is_store && !d_excp_any) ? d_st_strb : 4'b0;
assign wb_size_o  = wb_mshr_case ? m_size[m_match_idx]
                  : wb_hold_case ? h_size
                  : wb_ld_dc_case ? t_size[t_match_idx] : d_size;
assign wb_uncached_o = wb_ld_dc_case ? t_uncached[t_match_idx]
                     : (!wb_mshr_case && !wb_hold_case) && d_uncached;
assign wb_excp_o  = (!wb_mshr_case && !wb_hold_case && !wb_ld_dc_case)
                  ? d_excp : {`EXCP_NUM{1'b0}};
// The dependency wakeup bus describes data readiness, not ownership of the
// single architectural writeback port.  In particular, an older MSHR return
// may win that port while the hold/DC-hit value below is already usable by a
// dependent instruction.  Keeping this bus independent of wb_mshr_case both
// preserves the useful early wakeup and removes the DCache-MSHR -> ALU cone.
wire fast_hold_ready = h_valid;
wire fast_dc_ready = (`LSU_DC_HIT_BYPASS != 0) && dc_data_ok_i
                   && fast_tok_valid[dc_resp_robid_i];
assign fast_wb_valid_o = (fast_hold_ready || fast_dc_ready) && !flush_i;
assign fast_wb_robid_o = fast_hold_ready ? h_robid : dc_resp_robid_i;
assign fast_wb_data_o  = fast_hold_ready
                       ? h_data
                       : shape_load(dc_rdata_i, t_mem_op[t_match_idx][7:4],
                                    t_vaddr[t_match_idx][1:0]);
assign hold_wb_valid_o = h_valid && !flush_i;
assign hold_wb_robid_o = h_robid;
assign hold_wb_data_o  = h_data;

// ---------------- 流水推进 ----------------
// DC 级本拍腾空：写回成功、miss 完成条件到达，或已捕获进 hold。
wire d_done  = wb_excp_case || wb_st_case || wb_ld_sb_case
             || dc_fire || hold_cap_stq || hold_cap_sb;

// 年轻 UC park（宽版）：仅对【比 DC 中 UC 更老】的 AGU 让位。
// 勿对更年轻 AGU 让位（会覆盖 u / 堵 RS）；u_valid 期间禁更年轻进 DC。
// u_valid 期间禁止年轻请求进入 DC，避免覆盖停车槽或破坏程序序。
wire d_uc_yield = d_is_unc_load && !d_at_head && !d_req_sent && !d_drop;
wire u_at_head = u_valid
              && (u_robid[`ROB_PAIR_W-1:0] == head_pair)
              && ((u_robid[`ROB_W-1] == 1'b0) || !head_s0_live)
              && rob_head_valid_i;
wire [`ROB_PAIR_W-1:0] a_from_h = a_robid[`ROB_PAIR_W-1:0] - head_pair;
wire [`ROB_PAIR_W-1:0] d_from_h = d_robid[`ROB_PAIR_W-1:0] - head_pair;
wire [`ROB_PAIR_W-1:0] u_from_h = u_robid[`ROB_PAIR_W-1:0] - head_pair;
wire a_older_than_d = (a_from_h < d_from_h)
                   || ((a_from_h == d_from_h)
                       && (a_robid[`ROB_W-1] == 1'b0)
                       && (d_robid[`ROB_W-1] == 1'b1));
wire a_older_than_u = !u_valid
                   || (a_from_h < u_from_h)
                   || ((a_from_h == u_from_h)
                       && (a_robid[`ROB_W-1] == 1'b0)
                       && (u_robid[`ROB_W-1] == 1'b1));
wire u_reload = u_at_head && (!d_valid || d_done || d_uc_yield);
wire d_free   = !d_valid || d_done
             || (d_uc_yield && !u_valid && a_valid && a_older_than_d && !u_reload);
wire a_translate_ready = a_no_trans || mmu_d_ready_i;
wire a_go     = a_valid && a_translate_ready
              && d_free && !u_reload && a_older_than_u;
wire d_park   = (d_uc_yield && a_go && !u_valid) || (d_uc_yield && u_reload);

// Do not use a_go here: a_go contains the SB lookup result and formed the
// synthesized store_buffer -> rs_mem critical path.
assign lsu_ready_o = !q_valid && !flush_i;
wire issue_accept = issue_valid_i && lsu_ready_o;

always @(posedge clk) begin
    if (reset) begin
        a_valid    <= 1'b0;
        q_valid    <= 1'b0;
        d_valid    <= 1'b0;
        h_valid    <= 1'b0;
        u_valid    <= 1'b0;
        fast_tok_valid <= {`ROB_SIZE{1'b0}};
        for (sj = 0; sj < TOK_N; sj = sj + 1)
            t_valid[sj] <= 1'b0;
        for (sj = 0; sj < MISS_N; sj = sj + 1) begin
            m_valid[sj] <= 1'b0;
            m_drop[sj]  <= 1'b0;
        end
        for (sj = 0; sj < STQ_N; sj = sj + 1)
            stq_v[sj] <= 1'b0;
        stq_last_idx <= {STQ_W{1'b0}};
    end else if (flush_i) begin
        a_valid    <= 1'b0;
        q_valid    <= 1'b0;
        d_valid    <= 1'b0;
        h_valid    <= 1'b0;
        u_valid    <= 1'b0;
        fast_tok_valid <= {`ROB_SIZE{1'b0}};
        for (sj = 0; sj < TOK_N; sj = sj + 1)
            t_valid[sj] <= 1'b0;
        for (sj = 0; sj < STQ_N; sj = sj + 1)
            stq_v[sj] <= 1'b0;
        for (sj = 0; sj < MISS_N; sj = sj + 1) begin
            m_valid[sj] <= 1'b0;
            m_drop[sj]  <= 1'b0;
        end
    end else begin
        if ((dc_data_ok_i || dc_miss_i) && fast_tok_valid[dc_resp_robid_i])
            fast_tok_valid[dc_resp_robid_i] <= 1'b0;
        if (dc_fire)
            fast_tok_valid[d_robid] <= 1'b1;

        // ---- DCache 前端 token：返回/移交 miss 清项，新请求 addr_ok 分配 ----
        if (dc_return || dc_missed)
            t_valid[t_match_idx] <= 1'b0;
        if (dc_fire) begin
            t_valid[t_free_idx]    <= 1'b1;
            t_robid[t_free_idx]    <= d_robid;
            t_mem_op[t_free_idx]   <= d_mem_op;
            t_vaddr[t_free_idx]    <= d_vaddr;
            t_paddr[t_free_idx]    <= d_paddr;
            t_size[t_free_idx]     <= d_size;
            t_uncached[t_free_idx] <= d_uncached;
        end

        // ---- miss 槽：返回清槽 / miss 分配 ----
        if (mshr_return || mshr_return_drop) begin
            m_valid[m_match_idx] <= 1'b0;
            m_drop [m_match_idx] <= 1'b0;
        end
        if (dc_missed && m_has_free) begin
            m_valid[m_free_idx]  <= 1'b1;
            m_drop [m_free_idx]  <= 1'b0;
            m_robid[m_free_idx]  <= t_robid[t_match_idx];
            m_mem_op[m_free_idx] <= t_mem_op[t_match_idx];
            m_vaddr[m_free_idx]  <= t_vaddr[t_match_idx];
            m_paddr[m_free_idx]  <= t_paddr[t_match_idx];
            m_size [m_free_idx]  <= t_size[t_match_idx];
        end

        // ---- hold 暂存槽 ----
        if (wb_hold_case) begin
            h_valid <= 1'b0;
        end
        if (hold_cap_dc || hold_cap_stq || hold_cap_sb) begin
            h_valid <= 1'b1;
            h_robid <= hold_cap_dc ? t_robid[t_match_idx] : d_robid;
            h_data  <= hold_cap_dc ? shape_load(dc_rdata_i, t_mem_op[t_match_idx][7:4],
                                                t_vaddr[t_match_idx][1:0])
                     : hold_cap_stq ? shape_load(stq_youngest_data_r, d_mem_op[7:4],
                                                d_vaddr[1:0])
                                   : shape_load(sb_query_data_i, d_mem_op[7:4], d_vaddr[1:0]);
            h_vaddr <= hold_cap_dc ? t_vaddr[t_match_idx] : d_vaddr;
            h_paddr <= hold_cap_dc ? t_paddr[t_match_idx] : d_paddr;
            h_size  <= hold_cap_dc ? t_size[t_match_idx] : d_size;
        end

        // ---- 顺序保护：STQ 入/出 ----
        for (sj = 0; sj < STQ_N; sj = sj + 1) begin
            if (stq_done[sj])
                stq_v[sj] <= 1'b0;
        end
        if (wb_st_case && d_is_store) begin : stq_push
            integer sk;
            reg pushed;
            pushed = 1'b0;
            for (sk = 0; sk < STQ_N; sk = sk + 1) begin
                if (!pushed && !stq_v[sk]) begin
                    stq_v[sk]    <= 1'b1;
                    stq_id[sk]   <= d_robid;
                    stq_pa[sk]   <= d_paddr;
                    stq_data[sk] <= d_st_data;
                    stq_strb[sk] <= d_st_strb;
                    stq_uc[sk]   <= d_uncached;
                    stq_last_idx <= sk[STQ_W-1:0];
                    pushed = 1'b1;
                end
            end
        end

        // ---- DC 级 / UC park / reload ----
        if (d_done && !u_reload && !a_go) d_valid <= 1'b0;

        // park：把年轻 UC 挪到 u（可与 u_reload 交换）
        if (d_park) begin
            u_valid  <= 1'b1;
            u_robid  <= d_robid;
            u_mem_op <= d_mem_op;
            u_vaddr  <= d_vaddr;
            u_paddr  <= d_paddr;
            u_size   <= d_size;
        end else if (u_reload) begin
            u_valid <= 1'b0;
        end

        // reload：u 到头灌回 DC（NBA 读旧 u；与 d_park 交换时自然交叉）
        if (u_reload) begin
            d_valid    <= 1'b1;
            d_robid    <= u_robid;
            d_mem_op   <= u_mem_op;
            d_is_cacop <= 1'b0;
            d_is_store <= 1'b0;
            d_is_load  <= 1'b1;
            d_vaddr    <= u_vaddr;
            d_paddr    <= u_paddr;
            d_size     <= u_size;
            d_uncached <= 1'b1;
            d_excp     <= {`EXCP_NUM{1'b0}};
        end else if (a_go) begin
            d_valid    <= 1'b1;
            d_robid    <= a_robid;
            d_mem_op   <= a_mem_op;
            d_is_cacop <= a_is_cacop;
            d_is_store <= a_is_store_op && !a_is_cacop;
            d_is_load  <= a_is_load_op  && !a_is_cacop;
            d_vaddr    <= a_vaddr;
            d_paddr    <= a_paddr;
            d_st_data  <= a_st_data;
            d_st_strb  <= a_st_strb;
            d_size     <= a_size;
            d_uncached <= a_uncached;
            d_excp     <= a_excp;
        end
        // ---- rs_mem -> issue skid -> AGU ----
        // Oldest data in q wins when A advances. A new issue enters A
        // directly in the common no-stall case, or parks in q while A stalls.
        if (a_go || !a_valid) begin
            if (q_valid) begin
                a_valid    <= 1'b1;
                a_robid    <= q_robid;
                a_mem_op   <= q_mem_op;
                a_is_cacop <= q_is_cacop;
                a_cacop_op <= q_cacop_op;
                a_vaddr    <= q_vaddr;
                a_wdata    <= q_wdata;
                q_valid    <= 1'b0;
            end else if (issue_accept) begin
                a_valid    <= 1'b1;
                a_robid    <= issue_robid_i;
                a_mem_op   <= issue_mem_op_i;
                a_is_cacop <= issue_is_cacop_i;
                a_cacop_op <= issue_cacop_op_i;
                a_vaddr    <= issue_base_i + issue_imm_i;
                a_wdata    <= issue_wdata_i;
            end else begin
                a_valid    <= 1'b0;
            end
        end else if (issue_accept) begin
            q_valid    <= 1'b1;
            q_robid    <= issue_robid_i;
            q_mem_op   <= issue_mem_op_i;
            q_is_cacop <= issue_is_cacop_i;
            q_cacop_op <= issue_cacop_op_i;
            q_vaddr    <= issue_base_i + issue_imm_i;
            q_wdata    <= issue_wdata_i;
        end
    end
end

// DC 级 early2：仅在 `LSU_EARLY2_ENABLE` 且「写回有保证」时唤醒。
// bypass=0 时必须关 early2（否则依赖可能在 hold 写回前被唤醒，Linux hang）。
wire d_early_ok = (`LSU_EARLY2_ENABLE != 0)
                && (dc_return || (d_valid && d_is_load && !d_excp_any && !d_is_cacop))
                && !wb_mshr_case
                && (dc_return || (sb_ready && !hold_cap_dc));
assign early_wakeup_valid_o = d_early_ok && !flush_i && !reset;
assign early_wakeup_robid_o = dc_return ? t_robid[t_match_idx] : d_robid;

`ifdef SYNTHESIS
// synthesis translate_off
reg [63:0] lsu_store_order_stall_cyc;
reg [63:0] lsu_dc_wait_cyc;
reg [63:0] lsu_stq_full_cyc;
reg [63:0] lsu_issue_accept_cnt;
reg [63:0] lsu_q_full_cyc;
reg [63:0] lsu_a_block_cyc;
reg [63:0] lsu_d_cached_load_cyc;
reg [63:0] lsu_d_uncached_load_cyc;
reg [63:0] lsu_d_uncached_not_head_cyc;
reg [63:0] lsu_d_uncached_head_cyc;
reg [63:0] lsu_d_no_token_cyc;
reg [63:0] lsu_d_sb_wait_cyc;
reg [63:0] lsu_d_h_wait_cyc;
reg [63:0] lsu_d_dc_not_accept_cyc;
reg [63:0] lsu_dc_fire_cnt;
reg [63:0] lsu_dc_cached_fire_cnt;
reg [63:0] lsu_dc_uncached_fire_cnt;
reg [7:0]  lsu_stq_occ_now;
reg [7:0]  lsu_stq_occ_max;
reg [63:0] lsu_stq_occ_sum;
integer    lsu_stq_pc_i;
always @(*) begin
    lsu_stq_occ_now = 8'd0;
    for (lsu_stq_pc_i = 0; lsu_stq_pc_i < STQ_N; lsu_stq_pc_i = lsu_stq_pc_i + 1)
        if (stq_v[lsu_stq_pc_i] && !stq_done[lsu_stq_pc_i])
            lsu_stq_occ_now = lsu_stq_occ_now + 8'd1;
end
always @(posedge clk) begin
    if (reset) begin
        lsu_store_order_stall_cyc <= 64'd0;
        lsu_dc_wait_cyc           <= 64'd0;
        lsu_stq_full_cyc          <= 64'd0;
        lsu_issue_accept_cnt      <= 64'd0;
        lsu_q_full_cyc            <= 64'd0;
        lsu_a_block_cyc           <= 64'd0;
        lsu_d_cached_load_cyc     <= 64'd0;
        lsu_d_uncached_load_cyc   <= 64'd0;
        lsu_d_uncached_not_head_cyc <= 64'd0;
        lsu_d_uncached_head_cyc   <= 64'd0;
        lsu_d_no_token_cyc        <= 64'd0;
        lsu_d_sb_wait_cyc         <= 64'd0;
        lsu_d_h_wait_cyc          <= 64'd0;
        lsu_d_dc_not_accept_cyc   <= 64'd0;
        lsu_dc_fire_cnt           <= 64'd0;
        lsu_dc_cached_fire_cnt    <= 64'd0;
        lsu_dc_uncached_fire_cnt  <= 64'd0;
        lsu_stq_occ_max           <= 8'd0;
        lsu_stq_occ_sum           <= 64'd0;
    end else if (!flush_i) begin
        if (d_valid && d_is_load && !d_excp_any && store_order_block)
            lsu_store_order_stall_cyc <= lsu_store_order_stall_cyc + 64'd1;
        if (d_valid && d_req_sent && !d_drop)
            lsu_dc_wait_cyc <= lsu_dc_wait_cyc + 64'd1;
        if (stq_full)
            lsu_stq_full_cyc <= lsu_stq_full_cyc + 64'd1;
        if (issue_accept)
            lsu_issue_accept_cnt <= lsu_issue_accept_cnt + 64'd1;
        if (q_valid)
            lsu_q_full_cyc <= lsu_q_full_cyc + 64'd1;
        if (a_valid && !a_go)
            lsu_a_block_cyc <= lsu_a_block_cyc + 64'd1;
        if (d_valid && d_is_load && !d_uncached)
            lsu_d_cached_load_cyc <= lsu_d_cached_load_cyc + 64'd1;
        if (d_valid && d_is_load && d_uncached) begin
            lsu_d_uncached_load_cyc <= lsu_d_uncached_load_cyc + 64'd1;
            if (d_at_head)
                lsu_d_uncached_head_cyc <= lsu_d_uncached_head_cyc + 64'd1;
            else
                lsu_d_uncached_not_head_cyc <= lsu_d_uncached_not_head_cyc + 64'd1;
        end
        if (d_valid && d_is_load && !t_has_free)
            lsu_d_no_token_cyc <= lsu_d_no_token_cyc + 64'd1;
        if (d_valid && d_is_load && sb_query_needed && !sb_query_ready)
            lsu_d_sb_wait_cyc <= lsu_d_sb_wait_cyc + 64'd1;
        if (d_valid && d_is_load && h_valid)
            lsu_d_h_wait_cyc <= lsu_d_h_wait_cyc + 64'd1;
        if (dc_req_o && !dc_addr_ok_i)
            lsu_d_dc_not_accept_cyc <= lsu_d_dc_not_accept_cyc + 64'd1;
        if (dc_fire) begin
            lsu_dc_fire_cnt <= lsu_dc_fire_cnt + 64'd1;
            if (d_uncached)
                lsu_dc_uncached_fire_cnt <= lsu_dc_uncached_fire_cnt + 64'd1;
            else
                lsu_dc_cached_fire_cnt <= lsu_dc_cached_fire_cnt + 64'd1;
        end
        lsu_stq_occ_sum <= lsu_stq_occ_sum + {56'd0, lsu_stq_occ_now};
        if (lsu_stq_occ_now > lsu_stq_occ_max)
            lsu_stq_occ_max <= lsu_stq_occ_now;
        if (dc_missed && !d_drop && !m_has_free)
            $error("[%0t] LSU: miss with full miss-slots", $time);
    end
end
// synthesis translate_on
`endif

endmodule
